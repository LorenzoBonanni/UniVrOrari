package com.example.school_timetable.school_timetable;
import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {}
